package com.blackxit.ff;
import android.app.Notification; import android.app.NotificationChannel; import android.app.NotificationManager;
import android.app.Service; import android.content.BroadcastReceiver; import android.content.Context;
import android.content.Intent; import android.content.IntentFilter; import android.graphics.Canvas;
import android.graphics.Color; import android.graphics.Paint; import android.graphics.PixelFormat;
import android.os.IBinder; import android.view.Gravity; import android.view.LayoutInflater;
import android.view.MotionEvent; import android.view.View; import android.view.WindowManager;
import android.widget.CheckBox; import android.widget.ImageButton; import android.widget.LinearLayout;
import android.widget.SeekBar; import android.widget.TextView;
public class OverlayService extends Service {
    private WindowManager wm; private View panelView; private EspOverlayView espView;
    private WindowManager.LayoutParams panelParams, espParams;
    private LinearLayout tabAimbot, tabEsp, tabMisc; private BroadcastReceiver espReceiver;
    private static final String CH = "bff";
    @Override public void onCreate() {
        super.onCreate();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
            .createNotificationChannel(new NotificationChannel(CH,"BLACKXIT FF",NotificationManager.IMPORTANCE_LOW));
        startForeground(1,new Notification.Builder(this,CH).setContentTitle("BLACKXIT FF")
            .setContentText("Ativo").setSmallIcon(android.R.drawable.ic_menu_view).build());
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        espView=new EspOverlayView(this);
        espParams=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        wm.addView(espView,espParams);
        panelView=LayoutInflater.from(this).inflate(R.layout.overlay_panel,null);
        panelParams=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        panelParams.gravity=Gravity.TOP|Gravity.START; panelParams.x=0; panelParams.y=100;
        wm.addView(panelView,panelParams);
        bindViews(); setupDrag();
        espReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){
            String d=i.getStringExtra("data"); if(d!=null&&espView!=null) espView.updateEnemies(d);}};
        registerReceiver(espReceiver,new IntentFilter("com.blackxit.ff.ESP_DATA"),Context.RECEIVER_NOT_EXPORTED);
    }
    private void bindViews() {
        tabAimbot=panelView.findViewById(R.id.tab_aimbot);
        tabEsp=panelView.findViewById(R.id.tab_esp);
        tabMisc=panelView.findViewById(R.id.tab_misc);
        showTab(0);
        panelView.findViewById(R.id.btn_tab_aimbot).setOnClickListener(v->showTab(0));
        panelView.findViewById(R.id.btn_tab_esp).setOnClickListener(v->showTab(1));
        panelView.findViewById(R.id.btn_tab_misc).setOnClickListener(v->showTab(2));
        panelView.findViewById(R.id.btn_close).setOnClickListener(v->stopSelf());
        ((CheckBox)panelView.findViewById(R.id.cb_aimbot)).setOnCheckedChangeListener((b,c)->HackAccessibilityService.aimbotEnabled=c);
        SeekBar sb=panelView.findViewById(R.id.sb_fov); TextView tv=panelView.findViewById(R.id.tv_fov_value);
        sb.setMax(360); sb.setProgress(360);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean u){HackAccessibilityService.fovValue=p;tv.setText(p+".0");}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}});
        CheckBox cbEsp=panelView.findViewById(R.id.cb_esp);
        cbEsp.setOnCheckedChangeListener((b,c)->{HackAccessibilityService.espEnabled=c;espView.setVisibility(c?View.VISIBLE:View.GONE);});
        ((CheckBox)panelView.findViewById(R.id.cb_esp_box)).setOnCheckedChangeListener((b,c)->espView.drawBox=c);
        ((CheckBox)panelView.findViewById(R.id.cb_esp_line)).setOnCheckedChangeListener((b,c)->espView.drawLine=c);
        ((CheckBox)panelView.findViewById(R.id.cb_esp_name)).setOnCheckedChangeListener((b,c)->espView.drawName=c);
        ((CheckBox)panelView.findViewById(R.id.cb_esp_hp)).setOnCheckedChangeListener((b,c)->espView.drawHp=c);
        ((CheckBox)panelView.findViewById(R.id.cb_no_recoil)).setOnCheckedChangeListener((b,c)->HackAccessibilityService.noRecoilEnabled=c);
    }
    private void showTab(int t){
        tabAimbot.setVisibility(t==0?View.VISIBLE:View.GONE);
        tabEsp.setVisibility(t==1?View.VISIBLE:View.GONE);
        tabMisc.setVisibility(t==2?View.VISIBLE:View.GONE);
    }
    private void setupDrag(){
        final int[]ix={0},iy={0}; final float[]tx={0},ty={0};
        panelView.findViewById(R.id.panel_header).setOnTouchListener((v,e)->{
            switch(e.getAction()){
                case MotionEvent.ACTION_DOWN: ix[0]=panelParams.x;iy[0]=panelParams.y;tx[0]=e.getRawX();ty[0]=e.getRawY();return true;
                case MotionEvent.ACTION_MOVE: panelParams.x=ix[0]+(int)(e.getRawX()-tx[0]);panelParams.y=iy[0]+(int)(e.getRawY()-ty[0]);wm.updateViewLayout(panelView,panelParams);return true;
            } return false;
        });
    }
    @Override public void onDestroy(){super.onDestroy();if(panelView!=null)wm.removeView(panelView);if(espView!=null)wm.removeView(espView);if(espReceiver!=null)unregisterReceiver(espReceiver);}
    @Override public IBinder onBind(Intent i){return null;}
    static class EspOverlayView extends View {
        boolean drawBox=true,drawLine=false,drawName=false,drawHp=false;
        private final Paint box=new Paint(),line=new Paint(),txt=new Paint();
        private float[][]enemies=new float[0][];
        public EspOverlayView(Context c){super(c);box.setColor(Color.RED);box.setStyle(Paint.Style.STROKE);box.setStrokeWidth(3f);line.setColor(Color.YELLOW);line.setStrokeWidth(2f);txt.setColor(Color.WHITE);txt.setTextSize(28f);}
        public void updateEnemies(String data){String[]p=data.split(";");enemies=new float[p.length][4];for(int i=0;i<p.length;i++){String[]v=p[i].split(",");if(v.length==4){enemies[i][0]=Float.parseFloat(v[0]);enemies[i][1]=Float.parseFloat(v[1]);enemies[i][2]=Float.parseFloat(v[2]);enemies[i][3]=Float.parseFloat(v[3]);}}postInvalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);int h=getHeight(),cx=getWidth()/2;for(float[]e:enemies){if(drawBox)c.drawRect(e[0],e[1],e[0]+e[2],e[1]+e[3],box);if(drawLine)c.drawLine(cx,h,e[0]+e[2]/2,e[1]+e[3],line);if(drawName)c.drawText("Enemy",e[0],e[1]-5,txt);if(drawHp){Paint hp=new Paint();hp.setColor(Color.RED);c.drawRect(e[0],e[1]-15,e[0]+e[2],e[1]-8,hp);}}}
    }
}
