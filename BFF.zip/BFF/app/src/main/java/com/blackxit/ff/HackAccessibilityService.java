package com.blackxit.ff;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.List;
public class HackAccessibilityService extends AccessibilityService {
    public static boolean aimbotEnabled = false;
    public static boolean espEnabled = false;
    public static boolean noRecoilEnabled = false;
    public static float fovValue = 360f;
    public static String aimbotBone = "Cabeca";
    private final Handler handler = new Handler(Looper.getMainLooper());
    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        handler.post(noRecoilLoop);
        handler.post(aimbotLoop);
        sendBroadcast(new Intent("com.blackxit.ff.SERVICE_CONNECTED"));
    }
    private final Runnable noRecoilLoop = new Runnable() {
        @Override public void run() {
            if (noRecoilEnabled) {
                int cx = getResources().getDisplayMetrics().widthPixels / 2;
                int cy = getResources().getDisplayMetrics().heightPixels / 2;
                Path path = new Path();
                path.moveTo(cx, cy);
                path.lineTo(cx, cy + 2);
                dispatchGesture(new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, 50)).build(), null, null);
            }
            handler.postDelayed(this, 60);
        }
    };
    private final Runnable aimbotLoop = new Runnable() {
        @Override public void run() {
            if (aimbotEnabled) {
                List<AccessibilityWindowInfo> windows = getWindows();
                if (windows != null) {
                    int cx = getResources().getDisplayMetrics().widthPixels / 2;
                    int cy = getResources().getDisplayMetrics().heightPixels / 2;
                    for (AccessibilityWindowInfo w : windows) {
                        AccessibilityNodeInfo root = w.getRoot();
                        if (root != null) { findAndAim(root, cx, cy); root.recycle(); }
                    }
                }
            }
            handler.postDelayed(this, 100);
        }
    };
    private void findAndAim(AccessibilityNodeInfo node, int cx, int cy) {
        if (node == null) return;
        String id = node.getViewIdResourceName();
        if (id != null && (id.contains("enemy") || id.contains("target") || id.contains("player"))) {
            android.graphics.Rect b = new android.graphics.Rect();
            node.getBoundsInScreen(b);
            int tx = b.centerX();
            int ty = aimbotBone.equals("Cabeca") ? b.top + b.height()/5 : b.centerY();
            double dist = Math.sqrt(Math.pow(tx-cx,2)+Math.pow(ty-cy,2));
            float fovPx = (fovValue/360f)*Math.min(getResources().getDisplayMetrics().widthPixels,
                getResources().getDisplayMetrics().heightPixels)/2f;
            if (dist <= fovPx) {
                Path path = new Path(); path.moveTo(cx,cy); path.lineTo(tx,ty);
                dispatchGesture(new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path,0,80)).build(),null,null);
            }
        }
        for (int i=0;i<node.getChildCount();i++) findAndAim(node.getChild(i),cx,cy);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e==null) return;
        String pkg = e.getPackageName()!=null?e.getPackageName().toString():"";
        if (!pkg.equals("com.dts.freefireth")&&!pkg.equals("com.dts.freefiremax")) return;
        if (espEnabled) {
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows==null) return;
            StringBuilder sb = new StringBuilder();
            for (AccessibilityWindowInfo w : windows) {
                AccessibilityNodeInfo root = w.getRoot();
                if (root!=null) { collectNodes(root,sb); root.recycle(); }
            }
            if (sb.length()>0) { Intent i=new Intent("com.blackxit.ff.ESP_DATA"); i.putExtra("data",sb.toString()); sendBroadcast(i); }
        }
    }
    private void collectNodes(AccessibilityNodeInfo node, StringBuilder out) {
        if (node==null) return;
        String id = node.getViewIdResourceName();
        if (id!=null&&(id.contains("enemy")||id.contains("hp")||id.contains("player"))) {
            android.graphics.Rect b=new android.graphics.Rect(); node.getBoundsInScreen(b);
            out.append(b.left).append(",").append(b.top).append(",").append(b.width()).append(",").append(b.height()).append(";");
        }
        for (int i=0;i<node.getChildCount();i++) collectNodes(node.getChild(i),out);
    }
    @Override public void onInterrupt() { handler.removeCallbacksAndMessages(null); }
    @Override public void onDestroy() { super.onDestroy(); handler.removeCallbacksAndMessages(null); }
}
